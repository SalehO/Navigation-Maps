// main.cpp
//
// ICS 46 Winter 2018
// Project #5: Rock and Roll Stops the Traffic
//
// This is the program's main() function, which is the entry point for your
// console user interface.
#include "Digraph.hpp"
#include "RoadMapReader.hpp"
#include "RoadMapWriter.hpp"
#include "TripReader.hpp"
#include "RoadSegment.hpp"
#include "InputReader.hpp"
#include "Trip.hpp"
#include "TripMetric.hpp"
#include <iostream>
#include "RoadMap.hpp"
#include <iomanip>//setprecision
using namespace std;

int main()
{
	function<double(RoadSegment)> miles_func =[](const RoadSegment& e)
	{
		return e.miles/e.milesPerHour;
	};

	function<double(RoadSegment)> time_func =[](const RoadSegment& e)
	{
		return e.miles/e.milesPerHour;
	};


	InputReader read(cin);
	
	RoadMap di = RoadMapReader{}.readRoadMap(read);

	if(di.isStronglyConnected() == true )
	{
		vector<Trip> trips = TripReader{}.readTrips(read);
		 vector<int> directions;
		int index =0;
		double tot;


		int x =0;
		while(x <= trips.size()-1)
		{
			map<int, int> miles_map= di.findShortestPaths(trips [x].startVertex,miles_func);
			map<int, int> time_map = di.findShortestPaths(trips [x].startVertex,time_func) ;
			index = trips[x].endVertex;
			directions.clear();

			directions.push_back(trips[x].endVertex);
			int flag;
			tot = 0.00;
			if(TripMetric::Distance == trips[x].metric)
			{
				flag = 0;
			}
			else
			{
				flag = 1;
			}
			switch(flag)
			{

			case 0: //distance
			{
				cout<<"Shortest distance from"<<" "<<di.vertexInfo(trips[x].startVertex);
				cout<<" "<<"to"<<" "<<di.vertexInfo(trips[x].endVertex)<<":";
				//int j = index;
				for( int j = index ; trips[x].startVertex != j ; j = miles_map[j])
				{
					directions.push_back(miles_map[j]);	
					index = miles_map[index];

				}
				cout<<"\n\t Begin at"<<" "<< di.vertexInfo(directions[directions.size()-1])<< "\n";
				int g = directions[directions.size()-1];
				directions.pop_back(); //delete the one that i just printed
				for(int c =0 ; directions.empty() == false ; c++)
				{
					cout<<"\t Continue To"<<" "<<di.vertexInfo(directions[directions.size()-1])
					<<" "<<"("<<setprecision(1)<< fixed<<di.edgeInfo(g,directions[directions.size()-1]).miles
					<<" "<<"Miles )\n";
					double e_info =  di.edgeInfo(g,directions[directions.size()-1]).miles;
					g = directions[directions.size()-1];
					tot = e_info + tot;
					directions.pop_back();
				}

				cout<<"Total Distance:\t"<<fixed<<setprecision(1)<<tot<<" "<< "Miles\n\n";
				break;

			}

		

		  case 1:
		  	{
		  		//directions.clear();
		  		//time_map.clear();
		  		cout<<"Shortest Driving time from:"<<" "<<di.vertexInfo(trips[x].startVertex);
				cout<<" "<<"to"<<" "<<di.vertexInfo(trips[x].endVertex)<<":";
				for( int j = index ; trips[x].startVertex != index ; j = time_map[j])
				{
					directions.push_back(time_map[index]);	
					index = time_map[index];
				}
				cout<<"\n\t Begin at"<<" "<< di.vertexInfo(directions[directions.size()-1])<< "\n";
				//int last = directions.size()-1;
				int h = directions[directions.size()-1];
				directions.pop_back();

				for(int c =0 ; directions.empty() == false ; c++)
				{
					try{
					cout<<"\t Continue To"<<" "<< di.vertexInfo(directions[directions.size()-1])
					<<" "<<"("<<setprecision(1)<<fixed<< di.edgeInfo(h,directions[directions.size()-1]).miles
					<<" "<<"Miles"<<" @ " <<setprecision(1)<<fixed<<di.edgeInfo(h,directions[directions.size()-1]).milesPerHour;
					cout<< "mph ="<< " ";
					double sum = 60*60*(di.edgeInfo(h,directions[directions.size()-1]).miles /di.edgeInfo(h,directions[directions.size()-1]).milesPerHour);
					double hr =0.00;
					double m =0.00;
					double s =0.00;

					m = sum / 60.00;
					hr = m / 60.00;

					int mintutes_two = static_cast<int> (m); //change mins from double to int
					int h_2 = static_cast<int> (hr); // change hours from double to int


					s = (m - mintutes_two)*60;

					if(mintutes_two == 0 && h_2 ==0)
					{
						cout<<s<<" "<<"secs";
					}
					 if(mintutes_two != 0 && h_2 == 0)
					{
						cout<<mintutes_two<<" "<<"mins " << setprecision(1)<<fixed<<s<<" "<< "secs";
					}
					 if(mintutes_two != 0 && h_2 != 0)
					{
						cout<<h_2<<" "<<"hrs"<<mintutes_two<<" "<<"mins"<<setprecision(1)<<fixed<< s <<" "<<"secs";
					}
					cout<<")\n";
					tot = tot + sum;
					h = directions[directions.size()-1];
					directions.pop_back();
				}catch(...){};

					//tot = sum;
				}
					cout<<"Total time:  ";
					double hr =0.00;
					double m =0.00;
					double s =0.00;

					m = tot / 60.00;
					hr = m / 60.00;

					int mintutes_two = static_cast<int> (m); //change mins from double to int
					int h_2 = static_cast<int> (hr); // change hours from double to int


					s = (m - mintutes_two)*60;

					if(mintutes_two == 0 && h_2 ==0)
					{
						cout<<s<<" "<<"secs";
					}
					 if(mintutes_two != 0 && h_2 == 0)
					{
						cout<<mintutes_two<<" "<<"mins " << setprecision(1)<<fixed<<s<<" "<< "secs";
					}
					 if(mintutes_two != 0 && h_2 != 0)
					{
						cout<<h_2<<" "<<"hrs"<<mintutes_two<<" "<<"mins"<<setprecision(1)<<fixed<< s <<" "<<"secs";
					}
					cout<<"\n\n";
		  	}
		}
		cout<<"\n";
			++x;
		}

	}
    return 0;
}


